import argparse

def translate_midcds_ntseq(input_nt, codon_dict):
    output_aa = []
    baseidx = 0
    while (baseidx + 2) < len(input_nt):
        codon = input_nt[baseidx:(baseidx + 3)]
        aa = 'X'
        if codon in codon_dict:
            aa = codon_dict[codon]
        output_aa.append(aa)

        baseidx += 3
    return ''.join(output_aa)



parser = argparse.ArgumentParser(description = "")
parser.add_argument("--var", dest="input_variant_table", required=True, type=str, help=".var.tab file produced in this workflow")
parser.add_argument("--ref", dest="ref_allele_position_table", required=True, type=str, help="reference position - reference allele table prepared for this workflow")
parser.add_argument("--out", dest="output_mutation_table", required=True, type=str, help="output; table of annotated mutations detected in the sample")
parser.add_argument("--codon", dest="codon_dictionary_table", required=True, type=str, help="the standard genetic code in tab file: col 1 = codon nt, col 2 = aa, col 3 = start codon aa")

args = parser.parse_args()
input_variant_table = args.input_variant_table
ref_allele_position_table = args.ref_allele_position_table
output_mutation_table = args.output_mutation_table
codon_dictionary_table = args.codon_dictionary_table


"""
Read standard codon dictionary
"""
dict_standard_codon_aa = {}
dict_standard_codon_aa_start = {}
fr = open(codon_dictionary_table, 'r')
for line in fr:
    fields = line.strip().split("\t")
    codon_seq = fields[0]
    transl_aa = fields[1]
    transl_start_aa = fields[2]
    dict_standard_codon_aa[codon_seq] = transl_aa
    if transl_start_aa != '-':
        dict_standard_codon_aa_start[codon_seq] = transl_start_aa
fr.close()


"""
Step A
memorize the coding frame of the reference genome, position by position coding frame information
"""
dict_gnti_coding_frame = {}
n_frame_info_collection = 0
n_gnti = 0
fr = open(ref_allele_position_table, 'r')
line = fr.readline()
for line in fr:
    fields = line.strip().split("\t")
    locus_type = fields[0]      # 'CDS' / 'CDS_start' / 'NONCODING'
    locus_feature_name = fields[2]  # STR
    locus_infeat_coord_str = fields[3]
    locus_ref_ntseq = fields[4]
    locus_ref_aaseq = fields[5]
    gnti_list_str = fields[1].split(',')
    n_coord_in_locus = len(gnti_list_str)
    #
    for gnti_inlocus_index in range(n_coord_in_locus):
        gnti_obi = int(gnti_list_str[gnti_inlocus_index])
        frame_collection_for_gnti = []
        if gnti_obi in dict_gnti_coding_frame:
            frame_collection_for_gnti = dict_gnti_coding_frame[gnti_obi]
            print("  ... " + str(gnti_obi) + " double shot")

        list_frame_info = ['NA', 'NA', 0, 0, 'N']
        # list_frame_info = [feature_name STR, locus_type STR, infeat_aa_coord INT (0 if noncoding), pos_within_frame INT (0 if noncoding), ref_codon STR]
        #:  This pack of frame information can be dictionary-mapped one and only one genomic nt position
        #:  Meanwhile each genomic nt position may get mapped by one ore MORE packs of frame information (i.e., when involved in more than one way to the gene-coding)
        list_frame_info[0] = locus_feature_name
        list_frame_info[1] = locus_type
        if locus_type != 'NONCODING':
            list_frame_info[2] = int(locus_infeat_coord_str)
            list_frame_info[3] = gnti_inlocus_index + 1
        list_frame_info[4] = locus_ref_ntseq
        
        frame_collection_for_gnti.append(list_frame_info)
        n_frame_info_collection += 1

        dict_gnti_coding_frame[gnti_obi] = frame_collection_for_gnti
fr.close()

n_gnti = len(dict_gnti_coding_frame)

print("Reference genome position - coding frame information collection")
print("  ... n positions charted = " + str(n_gnti))
print("  ... n coding frame information charted = " + str(n_frame_info_collection))



"""
Step B
read through the sample's genomic nucleotide variant calls 
memorize a mapping: {genomic nt position --> original / changed}
(1) SNPs
(2) Q-insertions (reference allele is shorter / query longer)   -- Do refinement based on frame
(3) Q-deletions (reference allele is longer / query shorter)    -- Do refinement based on frame
"""
dict_refpos_nt_alt = {}
list_refobi_following_insert = []
dict_refobi_preceding_insertseq = {}

num_all_snp = 0
num_all_del = 0
num_all_ins = 0

fr = open(input_variant_table, 'r')
line = fr.readline()
for line in fr:
    fields = line.strip().split("\t")
    """
    ref     ref_position    ref_allele      query   query_allele    var_type
    NC_045512.2     241     C       ON247234.1      T       SNP
    NC_045512.2     936     C       ON247234.1      T       SNP
    NC_045512.2     6512    AGTT    ON247234.1      A       Q.DEL
    NC_045512.2     11282   AGTTTGTCTGGTTT  ON247234.1      AGTTT   Q.DEL
    NC_045512.2     22203   T       ON247234.1      TGAGCCAGAA      Q.IN
    ..         ...         ...      .. Q.IN
    """
    ref_pos_obi = int(fields[1])
    var_type = fields[5]
    ref_allele = fields[2]
    alt_allele = fields[4]

    if var_type == 'SNP':
        if alt_allele != 'N':
            dict_refpos_nt_alt[ref_pos_obi] = alt_allele
            num_all_snp += 1

    elif var_type == 'Q.DEL':
        ref_allele_len = len(ref_allele)
        alt_allele_len = len(alt_allele)
        refined_ref_allele_l = []
        refined_alt_allele_l = []
        frame_collection_for_gnti = dict_gnti_coding_frame[ref_pos_obi]
        frame_info = frame_collection_for_gnti[0]
        # if in NONCODING, just gap the query
        if frame_info[3] == 0:
            for intra_alt_zbi in range(alt_allele_len):
                absol_obi = ref_pos_obi + intra_alt_zbi
                ref_allele_nt = ref_allele[intra_alt_zbi]
                alt_allele_nt = alt_allele[intra_alt_zbi]
                refined_ref_allele_l.append(ref_allele_nt)
                refined_alt_allele_l.append(alt_allele_nt)
                if ref_allele_nt != alt_allele_nt:
                    if alt_allele != 'N':
                        dict_refpos_nt_alt[absol_obi] = alt_allele_nt
                        num_all_snp += 1
            for intra_ref_zbi in range(alt_allele_len, ref_allele_len):
                absol_obi = ref_pos_obi + intra_ref_zbi
                dict_refpos_nt_alt[absol_obi] = '-'
                refined_ref_allele_l.append(ref_allele[intra_ref_zbi])
                refined_alt_allele_l.append('-')
            
            num_all_del += 1
        # if in CDS, have to refine the gap position based on frame information
        else:
            alt_allele_split_len = 0
            
            alt_allele_split_len = 0
            buff_split_len = 0
            while buff_split_len <= alt_allele_len:
                codon_position_becomes = dict_gnti_coding_frame[ref_pos_obi + buff_split_len][0][3]
                if codon_position_becomes == 3:
                    alt_allele_split_len = buff_split_len
                buff_split_len += 1
            
            len_diff = ref_allele_len - alt_allele_len
            for intra_refallele_zbi in range(ref_allele_len):
                absol_ref_obi = ref_pos_obi + intra_refallele_zbi
                ref_allele_nt = ref_allele[intra_refallele_zbi]
                alt_allele_nt = '-'
                if intra_refallele_zbi < alt_allele_split_len:
                    alt_allele_nt = alt_allele[intra_refallele_zbi]
                elif intra_refallele_zbi < alt_allele_split_len + len_diff:
                    alt_allele_nt = '-'
                else:
                    alt_allele_nt = alt_allele[intra_refallele_zbi - len_diff]
                refined_ref_allele_l.append(ref_allele_nt)
                refined_alt_allele_l.append(alt_allele_nt)
                if ref_allele_nt != alt_allele_nt:
                    if alt_allele != 'N':
                        dict_refpos_nt_alt[absol_ref_obi] = alt_allele_nt
                        num_all_snp += 1
            
            num_all_del += 1
        print("Deletion before refine at ref " + str(ref_pos_obi))
        print("  ... REF " + ref_allele)
        print("  ... ALT " + alt_allele)
        print("Deletion after refine at ref " + str(ref_pos_obi))
        print("  ... REF " + ''.join(refined_ref_allele_l))
        print("  ... ALT " + ''.join(refined_alt_allele_l))
        print("//")

    elif var_type == 'Q.IN':
        ref_allele_len = len(ref_allele)
        alt_allele_len = len(alt_allele)
        refined_ref_allele_l = []
        refined_alt_allele_l = []
        frame_collection_for_gnti = dict_gnti_coding_frame[ref_pos_obi]
        frame_info = frame_collection_for_gnti[0]
        # if in NONCODING, place the insertion right after the ref allele's last position 
        if frame_info[3] == 0:
            for intra_allele_zbi in range(ref_allele_len):
                absol_obi = ref_pos_obi + intra_allele_zbi
                ref_allele_nt = ref_allele[intra_allele_zbi]
                alt_allele_nt = alt_allele[intra_allele_zbi]
                refined_ref_allele_l.append(ref_allele_nt)
                refined_alt_allele_l.append(alt_allele_nt)
                if ref_allele_nt != alt_allele_nt:
                    if alt_allele != 'N':
                        dict_refpos_nt_alt[absol_obi] = alt_allele_nt
                        num_all_snp += 1
            refined_ref_allele_l.append('(')
            refined_alt_allele_l.append('(')
            insert_allele_l = []
            for intra_allele_zbi in range(ref_allele_len, alt_allele_len):
                refined_ref_allele_l.append('-')
                refined_alt_allele_l.append(alt_allele[intra_allele_zbi])
                insert_allele_l.append(alt_allele[intra_allele_zbi])
            #
            ref_obi_following_insert = ref_pos_obi + ref_allele_len
            list_refobi_following_insert.append(ref_obi_following_insert)
            dict_refobi_preceding_insertseq[ref_obi_following_insert] = ''.join(insert_allele_l)
            num_all_ins += 1
            #
            refined_ref_allele_l.append(')')
            refined_alt_allele_l.append(')')
            refined_ref_allele_l.append('.' + str(ref_obi_following_insert))
        # if in CDS, have to refine the gap position based on frame information
        else:
            ref_allele_split_len = 0
            
            alt_allele_codonpos_array_pr = range(frame_info[3], frame_info[3] + alt_allele_len)
            alt_allele_codonpos_array = []
            for arri in range(alt_allele_len):
                alt_allele_codonpos_array.append(alt_allele_codonpos_array_pr[arri] % 3)

            ref_allele_split_len = 0
            buff_split_len = 0
            while buff_split_len <= ref_allele_len:
                codon_position_becomes = dict_gnti_coding_frame[ref_pos_obi + buff_split_len][0][3]
                if codon_position_becomes == 3:
                    ref_allele_split_len = buff_split_len
                buff_split_len += 1
            
            len_diff = alt_allele_len - ref_allele_len
            for intra_allele_zbi in range(ref_allele_split_len):
                absol_ref_obi = ref_pos_obi + intra_refallele_zbi
                ref_allele_nt = ref_allele[intra_allele_zbi]
                alt_allele_nt = alt_allele[intra_allele_zbi]
                refined_ref_allele_l.append(ref_allele_nt)
                refined_alt_allele_l.append(alt_allele_nt)
                if ref_allele_nt != alt_allele_nt:
                    if alt_allele != 'N':
                        dict_refpos_nt_alt[absol_ref_obi] = alt_allele_nt
                        num_all_snp += 1
            refined_ref_allele_l.append('(')
            refined_alt_allele_l.append('(')
            insert_allele_l = []
            for intra_allele_zbi in range(ref_allele_split_len, ref_allele_split_len + len_diff):
                alt_allele_nt = alt_allele[intra_allele_zbi]
                ref_allele_nt = '-'
                refined_ref_allele_l.append(ref_allele_nt)
                refined_alt_allele_l.append(alt_allele_nt)
                insert_allele_l.append(alt_allele_nt)
            refined_ref_allele_l.append(')')
            refined_alt_allele_l.append(')')
            #
            ref_obi_following_insert = ref_pos_obi + ref_allele_split_len
            list_refobi_following_insert.append(ref_obi_following_insert)
            dict_refobi_preceding_insertseq[ref_obi_following_insert] = ''.join(insert_allele_l)
            num_all_ins += 1
            #
            refined_ref_allele_l.append('.' + str(ref_obi_following_insert) + ' ')
            for intra_allele_zbi in range(ref_allele_split_len + len_diff, alt_allele_len):
                intra_refallele_zbi = intra_allele_zbi - len_diff
                ref_allele_nt = ref_allele[intra_refallele_zbi]
                alt_allele_nt = alt_allele[intra_allele_zbi]
                absol_obi = ref_pos_obi + intra_refallele_zbi
                if ref_allele_nt != alt_allele_nt:
                    dict_refpos_nt_alt[absol_ref_obi] = alt_allele_nt
                refined_ref_allele_l.append(ref_allele_nt)
                refined_alt_allele_l.append(alt_allele_nt)
        
        print("Insertion before refine at ref " + str(ref_pos_obi))
        print("  ... REF " + ref_allele)
        print("  ... ALT " + alt_allele)
        print("Insertion after refine at ref " + str(ref_pos_obi))
        print("  ... REF " + ''.join(refined_ref_allele_l))
        print("  ... ALT " + ''.join(refined_alt_allele_l))
        print("//")

    else:
        print("Unrecognized var_type [" + var_type + "] in your input variant table; " + input_variant_table)
fr.close()


print("  .. number of SNPs called in the sample = " + str(num_all_snp))
print("  .. number of deletions called in the sample = " + str(num_all_del))
print("  .. number of insertions called in the sample = " + str(num_all_ins))




"""
Step C
    - scan through every single reference coding frame unit (noncoding nt OR coding codon) along the dict_gnti_coding_frame
    - if any of the collected SNP/ DEL/ INS in dict_refpos_nt_alt/ dict_refobi_preceding_insertseq occur in the given frame,
    - write the mutation
"""

fw = open(output_mutation_table, 'w')
#   mutation_def_code   genomic_position    feature     aa_position     locus_type     ref     alt     ref_aa      alt_aa      var_type
fw.write("mutation_def_code\tgenomic_from\tgenomic_to\tfeature\tamino_acid_position\tlocus_type\tref_nt_allele\tsample_nt_allele\tref_aa_allele\tsample_aa_allele\tvariant_type\n")



fr = open(ref_allele_position_table, 'r')
line = fr.readline()
for line in fr:
    fields = line.strip().split("\t")
    locus_type = fields[0]      # 'NONCODING' / 'CDS' / 'CDS_start'
    locus_feature_name = fields[2]  # STR
    locus_infeat_coord_str = fields[3]  # '.' / 1-N
    locus_ref_ntseq = fields[4]     # 'A' / 'TAG'
    locus_ref_aaseq = fields[5]     # '.'
    gnti_list_str = fields[1].split(',')    # [i, i+1, i+2]
    n_coord_in_locus = len(gnti_list_str)

    alt_allele_list = []
    is_alt_null = False
    list_insert_after_this_loc = []
    
    # does locus (codon/nt) include SNP / deletion ? and even insertion ?
    got_snp = False
    got_insert = False
    for intra_locus_zbi in range(n_coord_in_locus):
        gnti = int(gnti_list_str[intra_locus_zbi])
        if gnti in dict_refpos_nt_alt:
            got_snp = True
            alt_allele_list.append(dict_refpos_nt_alt[gnti])
            if dict_refpos_nt_alt[gnti] == '-':
                is_alt_null = True
        else:
            alt_allele_list.append(locus_ref_ntseq[intra_locus_zbi])
        #
        if gnti in dict_refobi_preceding_insertseq:
            got_insert = True
            list_insert_after_this_loc.append(dict_refobi_preceding_insertseq[gnti])
    #
    if not (got_snp or got_insert):
        continue
    
    locus_gnti_from = gnti_list_str[0]
    locus_gnti_to = gnti_list_str[-1]
    
    if got_snp:
        alt_allele_nt = ''.join(alt_allele_list)
        alt_allele_aa = '.'
        if locus_type == 'CDS':
            alt_allele_aa = '-'
            if not is_alt_null:
                alt_allele_aa = 'X'
                if alt_allele_nt in dict_standard_codon_aa:
                    alt_allele_aa = dict_standard_codon_aa[alt_allele_nt]
        elif locus_type == 'CDS_start':
            alt_allele_aa = '-'
            if not is_alt_null:
                alt_allele_aa = 'X'
                if alt_allele_nt in dict_standard_codon_aa_start:
                    alt_allele_aa = dict_standard_codon_aa_start[alt_allele_nt]

        # synonymous or nonsynonymous mutation if SNP
        var_type = 'ncSNP'
        if locus_type != 'NONCODING':
            if locus_ref_aaseq == alt_allele_aa:
                var_type = 'Synonymous'
            else:
                var_type = 'Nonsynonymous'
        if is_alt_null:
            var_type = 'Deletion'

        mutation_def = locus_feature_name + ' ' + locus_ref_ntseq + locus_gnti_from + alt_allele_nt
        if locus_type != 'NONCODING':
            mutation_def = locus_feature_name + ' ' + locus_ref_aaseq + locus_infeat_coord_str + alt_allele_aa
        
        # write
        #   mutation_def_code   genomic_from    genome_to    feature     aa_position     locus_type     ref     alt     ref_aa      alt_aa      var_type
        fw.write(mutation_def)
        fw.write("\t" + locus_gnti_from)
        fw.write("\t" + locus_gnti_to)
        fw.write("\t" + locus_feature_name)
        fw.write("\t" + locus_infeat_coord_str)
        fw.write("\t" + locus_type)
        fw.write("\t" + locus_ref_ntseq)
        fw.write("\t" + alt_allele_nt)
        fw.write("\t" + locus_ref_aaseq)
        fw.write("\t" + alt_allele_aa)
        fw.write("\t" + var_type + "\n")
    else:   # == get_insert
        alt_allele_nt = list_insert_after_this_loc[0]
        
        # synonymous or nonsynonymous mutation if SNP
        var_type = 'Insertion'

        mutation_def = locus_feature_name + ' ' + locus_gnti_to + '-insert-' + alt_allele_nt
        if locus_type != 'NONCODING':
            alt_allele_aa = translate_midcds_ntseq(alt_allele_nt, dict_standard_codon_aa)
            mutation_def = locus_feature_name + ' ' + locus_infeat_coord_str + '-insert-' + alt_allele_aa
        
        # write
        #   mutation_def_code   genomic_from    genomic_to    feature     aa_position     locus_type     ref     alt     ref_aa      alt_aa      var_type
        fw.write(mutation_def)
        fw.write("\t" + locus_gnti_from)
        fw.write("\t" + locus_gnti_to)
        fw.write("\t" + locus_feature_name)
        fw.write("\t" + locus_infeat_coord_str)
        fw.write("\t" + locus_type)
        fw.write("\t" + locus_ref_ntseq)
        fw.write("\t" + alt_allele_nt)
        fw.write("\t" + locus_ref_aaseq)
        fw.write("\t" + alt_allele_aa)
        fw.write("\t" + var_type + "\n")

fr.close()
fw.close()
