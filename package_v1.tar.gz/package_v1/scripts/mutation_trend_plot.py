import os
import argparse
import subprocess
from datetime import datetime, date, timedelta



"""
Check if environment works.
"""
if 'COV_PKG_BASE' not in os.environ:
    print("You don't have environmental variable 'COV_PKG_BASE'")
    print("Add the following line to your ~/.bashrc file:")
    print("export COV_PKG_BASE=/path/to/package_v1")
    print("(where the /path/to/package_v1 part should be changed to the full-path to the directory 'package_v1' in your file system)")

    quit()

cov_package_base_dir = os.environ['COV_PKG_BASE']

sys_path_to_r_script = os.path.join(cov_package_base_dir, 'dependency', 'bin', 'mutation_trend_plot_R_script')


parser = argparse.ArgumentParser(description = "")
parser.add_argument("--sample-date", dest="sample_date_csv_file", required=True, type=str, help="CSV file containing first column: isolate ID, second column: collection date in 'YYYY-MM-DD' format. DO NOT have header row (DO NOT HAVE first row for column titles)")
parser.add_argument("--sample-record", dest="sample_record_csv_file", required=True, type=str, help="CSV file containing the rows from '*.sample_record.csv' files that were generated from 'quick_corona_mut' program")
parser.add_argument("--week-min-sample", dest="week_min_sample_size", required=False, default=10, type=int, help="Minimal sample size per week, for a week to be shown in the plots (default = 10)")
parser.add_argument("--week-min-freq", dest="mut_min_pctfreq_any_week", required=False, default=10, type=float, help="Minimal percent frequency of detection from any week, for a mutation to be shown in the plots (default = 10)")
parser.add_argument("--out", dest="output_png_file_prefix", required=True, type=str, help="Prefix for PNG files. It will create PREFIX.all.png, PREFIX.GENE_NAME.png, ...")
args = parser.parse_args()

sample_date_csv_file = args.sample_date_csv_file
sample_record_csv_file = args.sample_record_csv_file
week_min_sample_size = args.week_min_sample_size
mut_min_pctfreq_any_week = args.mut_min_pctfreq_any_week
output_png_file_prefix = args.output_png_file_prefix


"""
1. Collect the samples for which the collection date was validly presented in YYYY-MM-DD format
"""
list_isolate_id = []
dict_isolate_id_collection_date = {}
n_valid_isolate_in_input_csv = 0
n_total_isolate_in_input_csv = 0
earliest_collection_date = date(2099, 12, 31)
latest_collection_date = date(1900, 1, 1)

fr = open(sample_date_csv_file, 'r')
for line in fr:
    fields = line.strip().split(',')
    isolate_id = fields[0].strip('"')
    collection_date_str = fields[1].strip('"')
    collection_date_split = collection_date_str.split('-')
    valid_date_str = True
    n_total_isolate_in_input_csv += 1

    if len(collection_date_split) != 3:
        valid_date_str = False
        continue
    if len(collection_date_split[0]) != 4:
        valid_date_str = False
        continue
    if len(collection_date_split[1]) > 2 or int(collection_date_split[1]) > 12:
        valid_date_str = False
        continue
    if len(collection_date_split[2]) > 2:
        valid_date_str = False
        continue
    
    n_valid_isolate_in_input_csv += 1
    collection_date_y = int(collection_date_split[0])
    collection_date_m = int(collection_date_split[1])
    collection_date_d = int(collection_date_split[2])
    collection_date = date(collection_date_y, collection_date_m, collection_date_d)

    list_isolate_id.append(isolate_id)
    dict_isolate_id_collection_date[isolate_id] = collection_date

    if collection_date < earliest_collection_date:
        earliest_collection_date = collection_date
    if collection_date > latest_collection_date:
        latest_collection_date = collection_date

fr.close()

print("Samples recieved from the input CSV file " + sample_date_csv_file)
print("  ... number of isolates included in file = " + str(n_total_isolate_in_input_csv))
print("  ... number of isoaltes with valid collection date info = " + str(n_valid_isolate_in_input_csv))
print("  ... earliest collection date = " + earliest_collection_date.isoformat())
print("  ... latest collection date = " + latest_collection_date.isoformat())



"""
2. Among the isolates provided with collection date,
    sort out the ones whose 'quick_corona_mut' output paths are provided in the --sample-record CSV file
"""

dict_isolate_id_mutation_table_path = {}
n_valid_isolate_with_mutation_table = 0

fr = open(sample_record_csv_file, 'r')
# pass the header row
line = fr.readline()

for line in fr:
    fields = line.strip().split(',')

    isolate_id = fields[0].strip('"')
    mutation_table_path = fields[4].strip('"')

    if not os.path.isfile(mutation_table_path):
        # CANNOT BE USED case: because the mutation table promised in the sample-record CSV table is not found
        print("  ...  ... FAILS to MATCH due to mutation table path NOT FOUND: " + mutation_table_path)
        continue

    if isolate_id not in dict_isolate_id_collection_date:
        # CANNOT BE USED case: because the collection date for the isolate was not provided in --sample-date CSV file
        print("  ...  ... FAILS to MATCH due isolate collection date NOT PROVIDED: " + isolate_id)
        continue

    n_valid_isolate_with_mutation_table += 1
    dict_isolate_id_mutation_table_path[isolate_id] = mutation_table_path
fr.close()

print("MATCHING the samples provided with collection dates WITH the sample's mutation profile table information provided in: " + sample_record_csv_file)
print("  ... number of isolates with validly matched mutation profile file = " + str(n_valid_isolate_with_mutation_table) + '/' + str(n_valid_isolate_in_input_csv))



"""
3. Sorting the collection date range into the weekly intervals; 
    and map each isolate ID to the corresponding week index
"""
list_weekstart_date = []
#dict_weekstart_datestr_to_weekindex = {}
buff_weekindex = -1
buff_weekstart_date = earliest_collection_date
while buff_weekstart_date < latest_collection_date - timedelta(days = 6):
    list_weekstart_date.append(buff_weekstart_date)
    buff_weekindex += 1
    #dict_weekstart_datestr_to_weekindex[buff_weekstart_date.isoformat()] = buff_weekindex

    buff_weekstart_date += timedelta(days = 7)
dict_isoalte_id_to_weekindex = {}

n_total_week_interval = len(list_weekstart_date)
print("Number of weekly intervals from " + earliest_collection_date.isoformat() + " to " + latest_collection_date.isoformat() + " = " + str(n_total_week_interval))


"""
After counting up the number of isolates per weekly interval USING ONLY the isolates VALIDLY provided with mutation table and collection date, 
the effective weekly intervals can be smaller than the whole range.
"""

list_weekstart_sample_count = [0]*n_total_week_interval
dict_isolate_id_weekstart_index = {}

for isolate_index in range(len(list_isolate_id)):
    isolate_id = list_isolate_id[isolate_index]
    if isolate_id not in dict_isolate_id_mutation_table_path:
        continue
    if isolate_id not in dict_isolate_id_collection_date:
        continue

    isolate_collection_date = dict_isolate_id_collection_date[isolate_id]

    # going from last interval to the earlier week intervals
    #   the first encountering of isolate_collection_date >= weekstart_date means that the sample belongs to that week interval
    assigned_weekindex = -1
    for weekindex_subtr in range(1, n_total_week_interval + 1):
        weekindex = n_total_week_interval - weekindex_subtr
        if isolate_collection_date >= list_weekstart_date[weekindex]:
            assigned_weekindex = weekindex
            break
    
    #debug-purpose system output:
    #print("  week assignment: " + isolate_id + " FROM " + isolate_collection_date.isoformat() + " --> week index " + str(assigned_weekindex) + " STARTING " + list_weekstart_date[weekindex].isoformat())

    list_weekstart_sample_count[weekindex] += 1
    dict_isolate_id_weekstart_index[isolate_id] = assigned_weekindex

# How many week intervals get enough number of samples to be shown in the plot?
n_weekstart_to_plot = 0
list_weekstart_is_plottable = [False]*n_total_week_interval

for weekindex in range(n_total_week_interval):
    if list_weekstart_sample_count[weekindex] >= week_min_sample_size:
        n_weekstart_to_plot += 1
        list_weekstart_is_plottable[weekindex] = True
print("Number of weekly intervals where we have enough samples (" + str(week_min_sample_size) + " samples) to show plot = " + str(n_weekstart_to_plot))



"""
Now collect all mutations in the plotting-eligible samples.
"""
list_mut_def = []
list_mut_gcoord = []
dict_mut_def_feature = {}
dict_mut_def_type = {}
dict_mut_def_gcoord = {}
for isolate_index in range(len(list_isolate_id)):
    isolate_id = list_isolate_id[isolate_index]
    if isolate_id not in dict_isolate_id_mutation_table_path:
        continue
    if isolate_id not in dict_isolate_id_collection_date:
        continue

    assigned_weekindex = dict_isolate_id_weekstart_index[isolate_id]
    mutation_table_path = dict_isolate_id_mutation_table_path[isolate_id]

    fr = open(mutation_table_path, 'r')
    # pass the header row
    line = fr.readline()

    for line in fr:
        fields = line.strip().split("\t")
        mut_def = fields[0]
        feature = fields[3]
        gcoord = int(fields[1])
        mut_type = fields[10]

        if mut_def not in dict_mut_def_feature:
            dict_mut_def_feature[mut_def] = feature
            dict_mut_def_gcoord[mut_def] = gcoord
            dict_mut_def_type[mut_def] = mut_type
            list_mut_def.append(mut_def)
            list_mut_gcoord.append(gcoord)
        
    fr.close()

zipped_lists = zip(list_mut_gcoord, list_mut_def)
sorted_pairs = sorted(zipped_lists)
tuples = zip(*sorted_pairs)
sorted_list_mut_gcoord, sorted_list_mut_def = [ list(tuple) for tuple in  tuples]
num_mut_def = len(sorted_list_mut_def)

dict_mut_def_mut_index = {}
for mut_index in range(num_mut_def):
    dict_mut_def_mut_index[sorted_list_mut_def[mut_index]] = mut_index

print("Collected all mutations found across all isolates.")
print("  ... total number of different mutations = " + str(num_mut_def))


"""
4. Then for each mutation, find the maximum peak of weekly frequency across all date intervals.
-   in order to filter out the ones that never reach the threshold frequency 
"""
# create a 2-Dimensional count array
#   [sorted mutation index][week index among total week intervals] = number of positive sample for that mutation for that week
list_mut_list_weekly_count = []
for mut_index in range(num_mut_def):
    list_mut_list_weekly_count.append([0]*n_total_week_interval)

for isolate_index in range(len(list_isolate_id)):
    isolate_id = list_isolate_id[isolate_index]
    if isolate_id not in dict_isolate_id_mutation_table_path:
        continue
    if isolate_id not in dict_isolate_id_collection_date:
        continue

    assigned_weekindex = dict_isolate_id_weekstart_index[isolate_id]
    mutation_table_path = dict_isolate_id_mutation_table_path[isolate_id]

    fr = open(mutation_table_path, 'r')
    # pass the header row
    line = fr.readline()

    for line in fr:
        fields = line.strip().split("\t")
        mut_def = fields[0]
        mut_index = dict_mut_def_mut_index[mut_def]
        
        list_mut_list_weekly_count[mut_index][assigned_weekindex] += 1
    fr.close()

list_mut_peak_freq = [0]*num_mut_def
list_mut_is_plottable = [False]*num_mut_def
num_mut_plottable = 0
for mut_index in range(num_mut_def):
    peaking_pct_freq = 0
    for week_index in range(n_total_week_interval):
        if not list_weekstart_is_plottable[week_index]:
            continue

        n_sample_in_the_week = list_weekstart_sample_count[week_index]
        n_positive_in_the_week = list_mut_list_weekly_count[mut_index][week_index]
        pct_freq_in_the_week = 100*float(n_positive_in_the_week)/float(n_sample_in_the_week)

        if pct_freq_in_the_week > peaking_pct_freq:
            peaking_pct_freq = pct_freq_in_the_week
    
    list_mut_peak_freq[mut_index] = peaking_pct_freq
    if peaking_pct_freq >= mut_min_pctfreq_any_week:
        list_mut_is_plottable[mut_index] = True
        num_mut_plottable += 1
print("  ... the number of mutations that pass the threshold frequency (" + str(mut_min_pctfreq_any_week) + "%) in at least one week = " + str(num_mut_plottable))



"""
5. Now write a temporary file with the columns:
    mutation index, mutation def, week start date, percent frequency, feature name
and another temporary file:
    week start date, number of samples
"""
tmp_plotdata_tsv_week_info = output_png_file_prefix + '.tmp_tsv_weekinfo'
tmp_plotdata_tsv_mut_freq = output_png_file_prefix + '.tmp_tsv_mutfreq'

fw = open(tmp_plotdata_tsv_week_info, 'w')
fw.write("week_start\tn_sample\n")
for week_index in range(n_total_week_interval):
    if list_weekstart_is_plottable[week_index]:
        weekstart_str = list_weekstart_date[week_index].isoformat()
        weekstart_n_sample = list_weekstart_sample_count[week_index]
        fw.write(weekstart_str + "\t" + str(weekstart_n_sample) + "\n")
fw.close()

fw = open(tmp_plotdata_tsv_mut_freq, 'w')
fw.write("mut_index\tmut_def\tweek_start\tpercent_freq\tfeature_name\ttype\n")
for mut_index in range(num_mut_def):
    if not list_mut_is_plottable[mut_index]:
        continue
    mut_def = sorted_list_mut_def[mut_index]
    mut_feature = dict_mut_def_feature[mut_def]
    mut_type = dict_mut_def_type[mut_def]

    for week_index in range(n_total_week_interval):
        if not list_weekstart_is_plottable[week_index]:
            continue
        n_sample_in_the_week = list_weekstart_sample_count[week_index]
        n_positive_in_the_week = list_mut_list_weekly_count[mut_index][week_index]
        pct_freq_in_the_week = 100*float(n_positive_in_the_week)/float(n_sample_in_the_week)
        
        fw.write(str(mut_index) + "\t" + mut_def + "\t" + list_weekstart_date[week_index].isoformat() + "\t" + str(pct_freq_in_the_week) + "\t" + mut_feature  + "\t" + mut_type + "\n")
fw.close()


"""
6. Run the R script that create plots from the above two temporary files
"""

# mutation_trend_plot_R_script USA_DC_DEC_to_MAY.trend_plot.tmp_tsv_weekinfo USA_DC_DEC_to_MAY.trend_plot.tmp_tsv_mutfreq USA_DC_DEC_to_MAY.trend_plot
command_list = []
command_list.append(sys_path_to_r_script)
command_list.append(tmp_plotdata_tsv_week_info)
command_list.append(tmp_plotdata_tsv_mut_freq)
command_list.append(output_png_file_prefix)
print("RUN R SCRIPT: " + ' '.join(command_list))
subprocess.run(command_list)



"""
7. Clear the temporary files
"""
os.remove(tmp_plotdata_tsv_mut_freq)
os.remove(tmp_plotdata_tsv_week_info)


