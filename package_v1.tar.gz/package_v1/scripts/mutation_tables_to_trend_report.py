import os
import argparse


parser = argparse.ArgumentParser(description = "")
parser.add_argument("--in-mut-dir", dest="mutation_table_dir", required=True, type=str, help="directory containing mutation tables")
parser.add_argument("--mut-extension", dest="mutation_table_extension", required=False, default = '.mutation_profile.tab', type=str, help="default = '.mutation_profile.tab; file extensions given to the mutation tables")
parser.add_argument("--out-pa-table", dest="output_presence_matrix", required=True, type=str, help="output; CSV presence absence matrix for the mutations detected in the samples detected in the --in-mut-dir")
parser.add_argument("--out-fr-table", dest="output_frequency_table", required=True, type=str, help="output; CSV table of annotated mutations detected in the samples + overall frequency in the samples detected in the --in-mut-dir")

args = parser.parse_args()
mutation_table_dir = args.mutation_table_dir
mutation_table_extension = args.mutation_table_extension
output_presence_matrix = args.output_presence_matrix
output_frequency_table = args.output_frequency_table
# query_genome_fasta = args.query_genome_fasta



"""
Check input directory & List of samples in the input directory
"""
if not os.path.isdir(mutation_table_dir):
    print("--in-mut-dir directory " + mutation_table_dir + " cannot be found.")
    quit()

list_sample_id = []
list_sample_mut_tbl_path = []

list_filename_in_input = os.listdir(mutation_table_dir)
for filezbi in range(len(list_filename_in_input)):
    filename = list_filename_in_input[filezbi]
    if not filename.endswith(mutation_table_extension):
        continue
    sample_name = filename[:filename.rfind(mutation_table_extension)]
    sample_id = sample_name
    if sample_name.endswith('.'):
        sample_id = sample_name[:-1]
    
    mut_tbl_path = os.path.join(mutation_table_dir, filename)
    list_sample_id.append(sample_id)
    list_sample_mut_tbl_path.append(mut_tbl_path)
num_sample = len(list_sample_id)
print("Detected " + str(num_sample) + " sample results in the input directory")


"""
Collect list of mutations that were ever detected among the samples
"""
list_mut_id = []
list_mut_startcoord = []
dict_mut_id_index = {}
buff_mut_index = -1
dict_mut_id_attribute = {}
#   dict_mut_id_attribute:
#   mutation_id : [genomic_from, genomic_to, feature_name, locus_type, variant_type, amino_acid_position, ref_nt_allele, alt_nt_allele, ref_aa_allele, alt_aa_allele]
for sample_zbi in range(num_sample):
    mut_tbl_path = list_sample_mut_tbl_path[sample_zbi]
    fr = open(mut_tbl_path, 'r')
    line = fr.readline()
    for line in fr:
        fields = line.strip().split("\t")
        """
        [0] mutation_def_code   [1] genomic_from    [2] genomic_to
        [3] feature [4] amino_acid_position     [5] locus_type
        [6] ref_nt_allele   [7] sample_nt_allele
        [8] ref_aa_allele   [9] sample_aa_allele
        [10] variant_type        
        """
        mut_def = fields[0]
        genomic_from = fields[1]
        genomic_to = fields[2]
        feature_name = fields[3]
        amino_position = fields[4]
        locus_type = fields[5]
        ref_nt = fields[6]
        alt_nt = fields[7]
        ref_aa = fields[8]
        alt_aa = fields[9]
        var_type = fields[10]
        #
        genomic_from_int = int(genomic_from)
        mut_attribute = [genomic_from, genomic_to, feature_name, locus_type, var_type, amino_position, ref_nt, alt_nt, ref_aa, alt_aa]
        #
        if mut_def not in dict_mut_id_index:
            buff_mut_index += 1
            list_mut_id.append(mut_def)
            list_mut_startcoord.append(genomic_from_int)
            dict_mut_id_index[mut_def] = buff_mut_index
            dict_mut_id_attribute[mut_def] = mut_attribute
    fr.close()
num_mut_collected = len(list_mut_id)
print("Collected " + str(num_mut_collected) + " mutations throughout the samples in the directory")


"""
- frequency across all samples by mutation
- presence absence of each mutation in each sample
"""
list_mut_count_sample = [0]*num_mut_collected
matrix_sample_mutation_presence = []

for sample_zbi in range(num_sample):
    list_mutation_presence = [False]*num_mut_collected

    mut_tbl_path = list_sample_mut_tbl_path[sample_zbi]
    fr = open(mut_tbl_path, 'r')
    line = fr.readline()
    for line in fr:
        fields = line.strip().split("\t")
        """
        [0] mutation_def_code   [1] genomic_from    [2] genomic_to
        ...
        """
        mut_def = fields[0]
        mut_index = dict_mut_id_index[mut_def]

        list_mut_count_sample[mut_index] += 1
        list_mutation_presence[mut_index] = True
    fr.close()

    matrix_sample_mutation_presence.append(list_mutation_presence)



"""
sort mutations by genomic (start) position
"""
zipped_lists = zip(list_mut_startcoord, list_mut_id)
sorted_pairs = sorted(zipped_lists)
tuples = zip(*sorted_pairs)
sorted_mut_startcoord, sorted_mut_id = [ list(tuple) for tuple in  tuples]


"""
write frequency table
"""
fw = open(output_frequency_table, 'w')
fw.write('"mutation_definition","frequency_percent","genomic_from","genomic_to","coding_feature","locus_type","variant_type","amino_acid_position","ref_nt","alt_nt","ref_aa","alt_aa"')
fw.write("\n")

for sorted_mut_zbi in range(num_mut_collected):
    mut_id = sorted_mut_id[sorted_mut_zbi]
    mut_index = dict_mut_id_index[mut_id]
    mut_attribute = dict_mut_id_attribute[mut_id]
    #   mut_attribute = [genomic_from, genomic_to, feature_name, locus_type, var_type, amino_position, ref_nt, alt_nt, ref_aa, alt_aa]

    num_positive_sample = list_mut_count_sample[mut_index]
    pct_freq = float(num_positive_sample)*100/float(num_sample)
    pct_freq_rounded = round(pct_freq, 4)

    var_site_from = str(mut_attribute[0])
    var_site_to = str(mut_attribute[1])
    var_feature = mut_attribute[2]
    var_locus_type = mut_attribute[3]
    var_type = mut_attribute[4]
    var_amino_pos = str(mut_attribute[5])
    if mut_attribute[5] == '.':
        var_amino_pos = 'NA'
    var_ref_nt = mut_attribute[6]
    var_alt_nt = mut_attribute[7]
    var_ref_aa = mut_attribute[8]
    var_alt_aa = mut_attribute[9]

    fw.write('"' + mut_id + '",' + str(pct_freq_rounded) + '%')
    fw.write(','+ var_site_from + ',' + var_site_to + ',"' + var_feature + '"')
    fw.write(',"' + var_locus_type + '","' + var_type + '",' + var_amino_pos)
    # ref nt, alt nt, ref aa, alt aa
    fw.write(',"' + var_ref_nt + '","' + var_alt_nt + '","' + var_ref_aa + '","' + var_alt_aa + '"')
    fw.write("\n")
fw.close()



"""
write presence absence matrix
"""
fw = open(output_presence_matrix, 'w')
fw.write('"sample"')
for sorted_mut_zbi in range(num_mut_collected):
    mut_id = sorted_mut_id[sorted_mut_zbi]
    fw.write(',"' + mut_id + '"')
fw.write("\n")

for sample_zbi in range(num_sample):
    sample_id = list_sample_id[sample_zbi]
    fw.write('"' + sample_id + '"')
    for sorted_mut_zbi in range(num_mut_collected):
        mut_id = sorted_mut_id[sorted_mut_zbi]
        mut_index = dict_mut_id_index[mut_id]
        present_in_sample = matrix_sample_mutation_presence[sample_zbi][mut_index]
        if present_in_sample:
            fw.write(",1")
        else:
            fw.write(",0")
    fw.write("\n")
fw.close()
