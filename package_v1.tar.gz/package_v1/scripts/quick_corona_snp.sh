input_dir=$1

output_aln="${input_dir}.quick_snp.aln"
output_var="${input_dir}.quick_snp.var"
output_mut="${input_dir}.quick_snp.mut"

if [ ! -d ${output_aln} ]; then
	mkdir ${output_aln}
fi
if [ ! -d ${output_var} ]; then
	mkdir ${output_var}
fi
if [ ! -d ${output_mut} ]; then
	mkdir ${output_mut}
fi

for fasta_file in ${input_dir}/*.fasta
do

	filename="${fasta_file##*/}"
	sample_pre="${filename%.fasta}"
	

	/data0/pathogenomics_feature_db/install/minimap2/minimap2-2.24_x64-linux/minimap2 -a -o ${output_aln}/${sample_pre}.sam -x asm20 ref/reference.fasta ${fasta_file}
	samtools view -S -b ${output_aln}/${sample_pre}.sam > ${output_aln}/${sample_pre}.bam
	samtools sort -o ${output_aln}/${sample_pre}.sorted.bam ${output_aln}/${sample_pre}.bam
	samtools index ${output_aln}/${sample_pre}.sorted.bam
	samtools mpileup -u -f ref/reference.fasta ${output_aln}/${sample_pre}.sorted.bam > ${output_aln}/${sample_pre}.bcf
	bcftools view -c 0 -v snps,indels,mnps ${output_aln}/${sample_pre}.bcf > ${output_var}/${sample_pre}.vcf

	python /data0/home/kihyunee/coronavirus_test/package_v1/scripts/vcf_to_variant_tab.py --vcf ${output_var}/${sample_pre}.vcf --qid ${sample_pre} --out ${output_var}/${sample_pre}.var.tab

	python /data0/home/kihyunee/coronavirus_test/package_v1/scripts/variant_tab_to_feature_mutation_tab_V3.py --var ${output_var}/${sample_pre}.var.tab --ref /data0/home/kihyunee/coronavirus_test/package_v1/reference/reference.position_ref_allele.tsv --out ${output_mut}/${sample_pre}.mutation_profile.tab --codon package_v1/reference/standard_codon.tab

done
