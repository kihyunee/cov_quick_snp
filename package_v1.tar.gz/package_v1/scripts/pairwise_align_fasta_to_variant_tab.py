import argparse



parser = argparse.ArgumentParser(description = "")
parser.add_argument("--in_fasta", dest="input_paln_fasta", required=True, type=str, help="input pairwise alignment fasta: reference as first entry, query as second/last entry")
parser.add_argument("--out_tab", dest="output_var_table", required=True, type=str, help="variant position table, output")


args = parser.parse_args()
input_paln_fasta = args.input_paln_fasta
output_var_table = args.output_var_table


"""
get sequences in the input alignment fasta
"""
seq_str_ref = ""
seq_str_query = ""
aln_column_len = 0


list_seqid = []
list_seq = []
fr = open(input_paln_fasta, 'r')
line = fr.readline()
while line != '':
    if line.strip().startswith('>'):
        entry_seqid = line.strip()[1:]
        entry_seq_str_list = []
        line = fr.readline()
        while line != '':
            entry_seq_str_list.append(line.strip())
            line = fr.readline()
            if line.strip().startswith('>'):
                break
        #
        list_seqid.append(entry_seqid)
        list_seq.append(''.join(entry_seq_str_list))
    else:
        line = fr.readline()
fr.close()


num_seq_in_input = len(list_seqid)
if num_seq_in_input != 2:
    print("Your input fasta does not have 2 entries")
    quit()


seq_id_ref = list_seqid[0]
seq_str_ref = list_seq[0]
seq_id_query = list_seqid[1]
seq_str_query = list_seq[1]
aln_column_len = len(seq_str_ref)
print("Your input is " + str(aln_column_len) + " bp alignment between [" + seq_id_ref + "] and [" + seq_id_query + "]")


list_var_refpos = []
list_var_refallele = []
list_var_queryallele = []

buff_refpos_obi = 0
indel_gauge = 0
#   0: not began to build indel sequence yet
#   +1: is now one base into insertion (query BASE / ref GAP)
#   +2: is now two base into insertion (query BASE / ref GAP)
#   +n: ...
#   -1: is now one base into deletion (query GAP / ref BASE)
#   -2: is now two base into deletion (query GAP / ref BASE)
#   -n: ...
prev_refallele = 'X'
prev_queryallele = 'X'
buff_indel_refstart_obi = -1
list_indel_refside = []
list_indel_queryside = []

fw = open(output_var_table, 'w')
fw.write("ref\tref_position\tref_allele\tquery\tquery_allele\tvar_type\n")

for alnpos_zbi in range(aln_column_len):
    alnpos_ref_allele = seq_str_ref[alnpos_zbi].upper()
    alnpos_query_allele = seq_str_query[alnpos_zbi].upper()
    if alnpos_ref_allele != '-':
        buff_refpos_obi += 1
    #
    gapside = 'none'
    if alnpos_ref_allele == '-':
        if alnpos_query_allele == '-':
            gapside = 'both'
        else:
            gapside = 'ref'
    else:
        if alnpos_query_allele == '-':
            gapside = 'query'
        else:
            gapside = 'none'
    
    # insertion treatment
    if gapside == 'ref':
        # is insertion site
        if indel_gauge == 0:
            # just create insertion
            list_indel_refside.append(prev_refallele)
            list_indel_queryside.append(prev_queryallele)
            list_indel_queryside.append(alnpos_query_allele)
            buff_indel_refstart_obi = buff_refpos_obi - 1
            indel_gauge += 1
        elif indel_gauge > 0:
            # update the current insertion info
            indel_gauge += 1
            list_indel_queryside.append(alnpos_query_allele)
        else:   # was deletion upto previous position
            # report the previous deletion UNLESS this was the OPENING GAPs at the LEFT END of the alignment
            if prev_queryallele != 'X':
                fw.write(seq_id_ref + "\t" + str(buff_indel_refstart_obi) + "\t" + ''.join(list_indel_refside) + "\t" + seq_id_query + "\t" + ''.join(list_indel_queryside) + "\t" + "Q.DEL" + "\n")
            # initialize & create insertion
            list_indel_refside = []
            list_indel_queryside = []
            buff_indel_refstart_obi = 0
            indel_gauge = 0
            #
            list_indel_refside.append(prev_refallele)
            list_indel_queryside.append(prev_queryallele)
            list_indel_queryside.append(alnpos_query_allele)
            buff_indel_refstart_obi = buff_refpos_obi - 1
            indel_gauge += 1

    elif gapside == 'query':
        # is deletion site
        if indel_gauge == 0:
            # just create deletion
            list_indel_refside.append(prev_refallele)
            list_indel_refside.append(alnpos_ref_allele)
            list_indel_queryside.append(prev_queryallele)
            buff_indel_refstart_obi = buff_refpos_obi - 1
            indel_gauge -= 1
        elif indel_gauge < 0:
            # update the current deletion info
            indel_gauge -= 1
            list_indel_refside.append(alnpos_ref_allele)
        else:   # was insertion upto previous position
            # report the previous insertion UNLESS this was the OPENING GAPs at the LEFT END of the alignment
            if prev_refallele != 'X':
                fw.write(seq_id_ref + "\t" + str(buff_indel_refstart_obi) + "\t" + ''.join(list_indel_refside) + "\t" + seq_id_query + "\t" + ''.join(list_indel_queryside) + "\t" + "Q.IN" + "\n")
            # initialize & create deletion
            list_indel_refside = []
            list_indel_queryside = []
            buff_indel_refstart_obi = 0
            indel_gauge = 0
            #
            list_indel_refside.append(prev_refallele)
            list_indel_refside.append(alnpos_ref_allele)
            list_indel_queryside.append(prev_queryallele)
            buff_indel_refstart_obi = buff_refpos_obi - 1
            indel_gauge -= 1
    
    elif gapside == 'none':
        # is matched site
        if indel_gauge == 0:
            # just check if it's SNP site
            if alnpos_query_allele != alnpos_ref_allele:
                # is snp site so report
                fw.write(seq_id_ref + "\t" + str(buff_refpos_obi) + "\t" + alnpos_ref_allele + "\t" + seq_id_query + "\t" + alnpos_query_allele + "\t" + "SNP" + "\n")
        elif indel_gauge < 0:   # was deletion upto previous position
            # report the previous deletion UNLESS this was the OPENING GAPs at the LEFT END of the alignment
            if prev_queryallele != 'X':
                fw.write(seq_id_ref + "\t" + str(buff_indel_refstart_obi) + "\t" + ''.join(list_indel_refside) + "\t" + seq_id_query + "\t" + ''.join(list_indel_queryside) + "\t" + "Q.DEL" + "\n")
            # initialize indel
            list_indel_refside = []
            list_indel_queryside = []
            buff_indel_refstart_obi = 0
            indel_gauge = 0
        elif indel_gauge > 0:   # was insertion upto previous position
            # report the previous insertion UNLESS this was the OPENING GAPs at the LEFT END of the alignment
            if prev_refallele != 'X':
                fw.write(seq_id_ref + "\t" + str(buff_indel_refstart_obi) + "\t" + ''.join(list_indel_refside) + "\t" + seq_id_query + "\t" + ''.join(list_indel_queryside) + "\t" + "Q.IN" + "\n")
            # initialize indel
            list_indel_refside = []
            list_indel_queryside = []
            buff_indel_refstart_obi = 0
            indel_gauge = 0

    else:   # is both gapped, do nothing
        print("both sequences have gap after this reference position " + str(buff_refpos_obi))
    
    if (gapside != 'both') and (gapside != 'ref'):
        prev_refallele = alnpos_ref_allele
    if (gapside != 'both') and (gapside != 'query'):
        prev_queryallele = alnpos_query_allele

fw.close()