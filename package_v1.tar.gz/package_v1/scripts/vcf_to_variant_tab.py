import argparse



parser = argparse.ArgumentParser(description = "")
parser.add_argument("--vcf", dest="input_vcf", required=True, type=str, help="input vcf; limitation = reference should had a single sequence")
parser.add_argument("--qid", dest="query_id", required=True, type=str, help="query sequence id")
parser.add_argument("--out", dest="output_var_table", required=True, type=str, help="variant position table, output")

args = parser.parse_args()
query_id = args.query_id
input_vcf = args.input_vcf
output_var_table = args.output_var_table


fw = open(output_var_table, 'w')
fw.write("ref\tref_position\tref_allele\tquery\tquery_allele\tvar_type\n")

fr = open(input_vcf, 'r')
for line in fr:
    if line.strip().startswith('#'):
        continue

    fields = line.strip().split("\t")
    seq_id_ref = fields[0]
    ref_pos_obi_str = fields[1]
    ref_allele = fields[3]
    query_allele = fields[4]
    if fields[3].find(',') > 0:
        ref_allele = fields[3].split(',')[0]
    if fields[4].find(',') > 0:
        query_allele = fields[4].split(',')[0]

    var_type = 'SNP'

    ref_allele_len = len(ref_allele)
    query_allele_len = len(query_allele)
    if ref_allele_len > query_allele_len:
        var_type = 'Q.DEL'
    elif ref_allele_len < query_allele_len:
        var_type = 'Q.IN'

    fw.write(seq_id_ref + "\t" + ref_pos_obi_str + "\t" + ref_allele + "\t" + query_id + "\t" + query_allele + "\t" + var_type + "\n")
fw.close()
fr.close()
