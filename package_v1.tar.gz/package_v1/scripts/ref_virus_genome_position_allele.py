import argparse
import os


parser = argparse.ArgumentParser(description = "")
parser.add_argument("--fasta", dest="ref_virus_fasta", required=True, type=str, help="the viral reference genome sequence in fasta")
parser.add_argument("--feature", dest="feature_coord_table", required=True, type=str, help="the viral genome's feature coordinate table: col 1 = position S-E,S-E; col 2 = name; col 3 = type (NONCODING / CDS / CDS_mp) ")
parser.add_argument("--codon", dest="codon_dictionary_table", required=True, type=str, help="the standard genetic code in tab file: col 1 = codon nt, col 2 = aa, col 3 = start codon aa")
parser.add_argument("--out", dest="out_ref_allele_table", required=True, type=str, help="TSV file with columns: locus_category / nt_position / feature / aa_position / reference_nt / reference_aa")

"""
Output columns design
col 1 locus_cateogry:           'CDS' if inside 'CDS' or 'CDS_mp' / 'CDS_start' if at the start of 'CDS' / 'NONCODING' for everything else
col 2 genomic NT position csv:  single integer for 'NONCODING' / triplet of integers in csv for 'CDS' or 'CDS_start'
col 3 feature name:             CDS name / otherwise 'NONCODING' 
col 4 in-CDS AA position:       '.' if 'NONCODING' locus / single integer for 'CDS' or 'CDS_start' locus
col 5 reference NT allele:      single NT allele for 'NONCODING' locus / concatenated codon triplet sequence for 'CDS' or 'CDS_start' locus
col 6 reference AA allele:      '.' if 'NONCODING' locus / 'X' if ambiguous base presence in 'CDS' or 'CDS_start' locus / single AA allele for 'CDS' or 'CDS_start' locus without ambiguous base
"""

args = parser.parse_args()
ref_virus_fasta = args.ref_virus_fasta
feature_coord_table = args.feature_coord_table
codon_dictionary_table = args.codon_dictionary_table
out_ref_allele_table = args.out_ref_allele_table


"""
Read standard codon dictionary
"""
dict_standard_codon_aa = {}
dict_standard_codon_aa_start = {}
fr = open(codon_dictionary_table, 'r')
for line in fr:
    fields = line.strip().split("\t")
    codon_seq = fields[0]
    transl_aa = fields[1]
    transl_start_aa = fields[2]
    dict_standard_codon_aa[codon_seq] = transl_aa
    if transl_start_aa != '-':
        dict_standard_codon_aa_start[codon_seq] = transl_start_aa
fr.close()




"""
Read reference genome into string
"""
ref_seq_id = ''
ref_seq_str = ''
ref_seq_str_l = []
fr = open(ref_virus_fasta, 'r')
line = fr.readline()
while line != '':
    if line.strip().startswith('>'):
        ref_seq_id = line.strip()[1:]
        line = fr.readline()
        while line != '':
            ref_seq_str_l.append(line.strip())
            line = fr.readline()
            if line.strip().startswith('>'):
                break
        ref_seq_str = ''.join(ref_seq_str_l)
        break
    else:
        line = fr.readline()
fr.close()

ref_seq_length = len(ref_seq_str)
print("Refernece sequence = " + ref_seq_id + " ... " + str(ref_seq_length) + " nucleotides")



"""
1-265   5UTR    NONCODING
266-805 ORF1ab leader protein   CDS
806-2719        ORF1ab nsp2     CDS_mp
2720-8554       ORF1ab nsp3     CDS_mp
8555-10054      ORF1ab nsp4     CDS_mp
10055-10972     ORF1ab 3C-like proteinase       CDS_mp
10973-11842     ORF1ab nsp6     CDS_mp
12092-12685     ORF1ab nsp8     CDS_mp
12686-13024     ORF1ab nsp9     CDS_mp
13025-13441     ORF1ab nsp10    CDS_mp
13442-13468,13468-16236 ORF1ab RNA-dependent RNA polymerase     CDS_mp
16237-18039     ORF1ab helicase CDS_mp
...
"""

fw = open(out_ref_allele_table, 'w')
fw.write("locus_type\tgenomic_nt_pos\tfeature_name\tin_cds_aa_pos\tref_nt_allele\tref_aa_allele\n")

fr = open(feature_coord_table, 'r')
for line in fr:
    fields = line.strip().split("\t")
    feat_coord_csvexp = fields[0].split(',')
    list_feat_start_obi = []
    list_feat_end_obi = []
    for expidx in range(len(feat_coord_csvexp)):
        csvexp = feat_coord_csvexp[expidx].split('-')
        list_feat_start_obi.append(int(csvexp[0]))
        list_feat_end_obi.append(int(csvexp[1]))
    feat_name = fields[1]
    feat_type = fields[2]

    if (feat_type == 'CDS') or (feat_type == 'CDS_mp'):
        locus_type = 'CDS_start'   # 'CDS' / 'CDS_start' / 'NONCODING'
        if feat_type == 'CDS_mp':
            locus_type = 'CDS'
        
        buff_cds_aa_pos = 0

        for coord_range_index in range(len(list_feat_start_obi)):
            range_start_obi = list_feat_start_obi[coord_range_index]
            range_end_obi = list_feat_end_obi[coord_range_index]
            #
            base_obi = range_start_obi
            while base_obi < range_end_obi:
                base_zbi_from = base_obi - 1
                base_zbi_end_by = base_zbi_from + 3
                buff_cds_aa_pos += 1
                position_obi_triplet = ','.join([str(base_obi), str(base_obi+1), str(base_obi+2)])

                nt_triplet = ref_seq_str[base_zbi_from:base_zbi_end_by]
                translated_aa = 'X'
                if locus_type == 'CDS':
                    if nt_triplet in dict_standard_codon_aa:
                        translated_aa = dict_standard_codon_aa[nt_triplet]
                elif locus_type == 'CDS_start':
                    if nt_triplet in dict_standard_codon_aa_start:
                        translated_aa = dict_standard_codon_aa_start[nt_triplet]
                
                # write in fw an output line
                # fw.write("locus_type\tgenomic_nt_pos\tfeature_name\tin_cds_aa_pos\tref_nt_allele\tref_aa_allele\n")
                fw.write(locus_type + "\t" + position_obi_triplet + "\t" + feat_name + "\t" + str(buff_cds_aa_pos) + "\t" + nt_triplet + "\t" + translated_aa + "\n")

                # iter
                locus_type = 'CDS'
                base_obi += 3
    #
    else:
        # non-coding
        locus_type = 'NONCODING'
        null_cds_aa_pos = '.'

        for coord_range_index in range(len(list_feat_start_obi)):
            range_start_obi = list_feat_start_obi[coord_range_index]
            range_end_obi = list_feat_end_obi[coord_range_index]
            #
            base_obi = range_start_obi
            while base_obi <= range_end_obi:
                base_zbi = base_obi - 1
                nt_single = ref_seq_str[base_zbi]
                null_aa = '.'
                # write in fw an output line
                # fw.write("locus_type\tgenomic_nt_pos\tfeature_name\tin_cds_aa_pos\tref_nt_allele\tref_aa_allele\n")
                fw.write(locus_type + "\t" + str(base_obi) + "\t" + feat_name + "\t" + str(null_cds_aa_pos) + "\t" + nt_single + "\t" + null_aa + "\n")

                base_obi += 1

fr.close()
fw.close()